package com.example.probnic3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;

import com.example.probnic3.databinding.ActivityMain2Binding;
import com.yandex.mapkit.Animation;
import com.yandex.mapkit.GeoObject;
import com.yandex.mapkit.MapKitFactory;
import com.yandex.mapkit.geometry.Geometry;
import com.yandex.mapkit.geometry.Point;
import com.yandex.mapkit.map.CameraPosition;
import com.yandex.mapkit.map.ModelParams;
import com.yandex.mapkit.mapview.MapView;
import com.yandex.mapkit.search.Response;
import com.yandex.mapkit.search.SearchFactory;
import com.yandex.mapkit.search.SearchManager;
import com.yandex.mapkit.search.SearchManagerType;
import com.yandex.mapkit.search.SearchOptions;
import com.yandex.mapkit.search.Session;
import com.yandex.mapkit.search.ToponymObjectMetadata;
import com.yandex.runtime.Error;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class doctor extends AppCompatActivity {
    ActivityMain2Binding binding2;
    private final String MAPKIT_API_KEY = "bfdfc8c7-bb74-4c23-aba9-28b5a05bc800";
    private final Point TARGET_LOCATION = new Point(55.0459, 82.9069);
    public List<Address> a;
    private MapView mapView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        MapKitFactory.setApiKey(MAPKIT_API_KEY);
        MapKitFactory.initialize(this);

        binding2 = ActivityMain2Binding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(binding2.getRoot());
        String name = getIntent().getStringExtra("name2");

        mapView = (MapView) findViewById(R.id.mapview);

        mapView.getMap().move(
                new CameraPosition(TARGET_LOCATION, 14.0f, 0.0f, 0.0f),
                new Animation(Animation.Type.SMOOTH, 5),
                null);
        Point mappoint2 = new Point(55.045965, 82.906955);
        mapView.getMap().getMapObjects().addPlacemark(mappoint2);
        /*Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            a = geocoder.getFromLocationName("Нарымская", 10, );
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Address i: a) {
            Point mappoint= new Point(i.getLatitude(), i.getLongitude());
            mapView.getMap().getMapObjects().addPlacemark(mappoint);
        }*/

        SearchManager searchManager = SearchFactory.getInstance().createSearchManager(SearchManagerType.ONLINE);
        Geometry point = Geometry.fromPoint(new Point(55.045965, 82.906955));
        searchManager.submit("Железнодорожная 1", point, new SearchOptions(), new Session.SearchListener() {
            @Override
            public void onSearchResponse(@NonNull Response response) {
                Point pointBySearch = response.getCollection()
                        .getChildren().get(0).getObj()
                        .getMetadataContainer().getItem(ToponymObjectMetadata.class)
                        .getBalloonPoint();
                mapView.getMap().getMapObjects().addPlacemark(pointBySearch);

            }

            @Override
            public void onSearchError(@NonNull Error error) {

            }
        });

/*
        Geocoder coder = new Geocoder(this);
        List<Address> address;
        try {
            address = coder.getFromLocationName("Железнодорожная 1", 5);
            if (address.size() > 0){
                Address location = address.get(0);
            Point mappoint= new Point(location.getLatitude(), location.getLongitude());
            mapView.getMap().getMapObjects().addPlacemark(mappoint);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
    @Override
    protected void onStop () {
        // Вызов onStop нужно передавать инстансам MapView и MapKit.
        mapView.onStop();
        MapKitFactory.getInstance().onStop();
        super.onStop();
    }

    @Override
    protected void onStart () {
        // Вызов onStart нужно передавать инстансам MapView и MapKit.
        super.onStart();
        MapKitFactory.getInstance().onStart();
        mapView.onStart();
    }
}